document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('identify-form');
  const fileInput = document.getElementById('plant-image');

  form.addEventListener('submit', async (event) => {
    event.preventDefault();

    if (!fileInput.files.length) {
      alert('Please upload an image of the plant.');
      return;
    }

    const file = fileInput.files[0];

    // Validate file type
    if (!file.type.startsWith('image/')) {
      alert('Only image files are allowed.');
      return;
    }

    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to identify plant. Please try again later.');
      }

      const data = await response.json();

      // Save to localStorage for result.html to use
      localStorage.setItem('identificationResult', JSON.stringify(data));

      // Redirect to result page
      window.location.href = 'result.html';
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  });
});
